================================================================
**bedtools**: *a powerful toolset for genome arithmetic*
================================================================

=================
Overview
=================

Brief paragraph of the software.


=================
Table of contents
=================
.. toctree::
   :maxdepth: 1

   content/overview
   content/installation
   content/quick-start
   content/general-usage
   content/bedtools-suite
   content/example-usage
   content/advanced-usage


=================
Mailing list
=================
Refer to the mailing list.

